<?php $__env->startSection('body'); ?>
<div class="container-xxl container-p-y">
    <div class="row">
        <div class="col-12">
            <div class="card table-responsive text-nowrap">
                <div class="d-flex">
                    <div class="col-12">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Member Details 🎉</h5>
                            <div class="card col-12">
                                <div class="col-12">
                                    <table class="table table-dark col-12">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Home Address</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Alternative Phone</th>
                                                <th>Gender</th>
                                                <th>Package Status</th>
                                                <th>Current Weight</th>
                                                <th>NID/Birth Certificate Number</th>
                                                <th>RFID No.</th>
                                                <th>Status</th>
                                                <th>Photo</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>

                                        <?php $__empty_1 = true; $__currentLoopData = $user_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tbody class="table-border-bottom-0">
                                                <tr>
                                                    <td><?php echo e($user->applicant_name); ?></td>
                                                    <td><?php echo e($user->home_address); ?></td>
                                                    <td><?php echo e($user->applicant_email); ?></td>
                                                    <td><?php echo e($user->phone_number); ?></td>
                                                    <td><?php echo e($user->alternative_phone_number); ?></td>
                                                    <td><?php echo e($user->gender); ?></td>
                                                    <td><?php echo e($user->package_status); ?></td>
                                                    <td><?php echo e($user->current_weight); ?></td>
                                                    <td><?php echo e($user->nid_number); ?></td>
                                                    <td><?php echo e($user->rfid_number); ?></td>
                                                    <td>
                                                        <li data-bs-toggle="tooltip"  class="avatar avatar-xs pull-up">
                                                            <img src="<?php echo e(asset('images/applicant_image/'.$user->applicant_image)); ?>" alt="Avatar" class="rounded-circle" />
                                                        </li>
                                                    </td>
                                                    <td><span class="badge bg-label-primary me-1">Active</span></td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                                <i class="bx bx-dots-vertical-rounded"></i>
                                                            </button>
                                                            <div class="dropdown-menu">
                                                                <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                                                <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tbody>
                                                <tr>
                                                    <td colspan="13" class="text-center">No members found.</td>
                                                </tr>
                                            </tbody>
                                        <?php endif; ?>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sneat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shredded/public_html/shreded_fitness/resources/views/member_registration/member_details.blade.php ENDPATH**/ ?>