<?php $__env->startSection('body'); ?>
<div class="container-xxl container-p-y">
              <div class="row">
                <div class="col-12">
                  <div class="card table-responsive text-nowrap ">
                    <div class="d-flex ">
                      <div class="col-12">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Member Details 🎉</h5>
                          <div class="card col-12">
                            <div class="col-12">
                              <table class="table table-dark col-12">
                                <thead>
                                  <tr>
                                    <th>Name</th>
                                    <th>Home Address</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Alternative Phone</th>
                                    <th>Gender</th>
                                    <th>Current Weight</th>
                                    <th>NID/Birth Certificate Number</th>
                                    <th>NID/Birth Certificate Number</th>
                                    <th>RFID No.</th>
                                    <th>Status</th>
                                    <th>Photo</th>
                                    <th>Actions</th>
                                  </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                  <tr>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Someone</strong></td>
                                    <td>dhaka</td>
                                    <td>xyz@mail.com</td>
                                    <td>+880015635</td>
                                    <td>+88001456789</td>
                                    <td>male</td>
                                    <td>6.5 inch</td>
                                    <td>698033</td>
                                    <td>1234587</td>
                                    <td>12</td>
                                    <td>
                                      <li
                              data-bs-toggle="tooltip"
                              data-popup="tooltip-custom"
                              data-bs-placement="top"
                              class="avatar avatar-xs pull-up"
                              title="Christina Parker"
                            >
                              <img src="../assets/img/avatars/7.png" alt="Avatar" class="rounded-circle" />
                            </li>
                                    </td>
                                    <td><span class="badge bg-label-primary me-1">Active</span></td>
                                    <td>
                                      <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                          <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                          <a class="dropdown-item" href="javascript:void(0);"
                                            ><i class="bx bx-edit-alt me-1"></i> Edit</a
                                          >
                                          <a class="dropdown-item" href="javascript:void(0);"
                                            ><i class="bx bx-trash me-1"></i> Delete</a
                                          >
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sneat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Shreded Fitness\shreded_fitness\resources\views/member_registration/member_details.blade.php ENDPATH**/ ?>